<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Ryan Choennie">
    <meta charset="UTF-8">
    <title>Garage update auto1</title>
</head>
<body>
<h1>Garage update auto 1</h1>
<p>
    Dit formulier word gebruikt om autogegevens te wijzigen.
</p>
<form action="gar-update-auto2.php" method="post">
    Welke autokenteken wilt u wijzigen?
    <input type="text" name="autokentekenvak"> <br />
    <input type="submit">
</form>

</body>
</html>