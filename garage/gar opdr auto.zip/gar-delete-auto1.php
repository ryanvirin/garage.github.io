<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Ryan Choennie">
    <meta charset="UTF-8">
    <title>Garage delete auto1</title>
</head>
<body>
<h1>Garage delete auto 1</h1>
<p>
    Dit formulier zoekt een auto op uit
    de tabel auto's van database garage
    om hem te kunnen verwijderen.
</p>
<form action="gar-delete-auto2.php" method="post">
    Welke autokenteken wilt u verwijderen?
    <input type="text" name="autokentekenvak"> <br />
    <input type="submit">
</form>

</body>
</html>