<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Ryan Choennie">
    <meta charset="UTF-8">
    <title>Garage search auto1</title>
</head>
<body>
<h1>Garage zoek op autokenteken 1</h1>
<p>
    Dit formulier zoekt een autokenteken op uit
    de tabel auto van database garage.
</p>
<form action="gar-search-auto2.php" method="post">
    Welke klant zoekt u?
    <input type="text" name="autokentekenvak"> <br />
    <input type="submit">
</form>

</body>
</html>