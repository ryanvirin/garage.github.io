<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Ryan Choennie">
    <meta charset="UTF-8">
    <title>Garage update klant1</title>
</head>
<body>
<h1>Garage update klant 1</h1>
<p>
    Dit formulier word gebruikt om klantgegevens te wijzigen.
</p>
<form action="gar-update-klant2.php" method="post">
    Welke klantid wilt u wijzigen?
    <input type="text" name="klantidvak"> <br />
    <input type="submit">
</form>

</body>
</html>