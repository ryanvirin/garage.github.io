<!doctype html>
<html lang="nl">
<head>
    <meta name="author" content="Ryan Choennie">
    <meta charset="UTF-8">
    <title>Garage search klant1</title>
</head>
<body>
<h1>Garage zoek op klantid 1</h1>
<p>
    Dit formulier zoekt een klant op uit
    de tabel klanten van database garage.
</p>
<form action="gar-search-klant2.php" method="post">
    Welke klant zoekt u?
    <input type="text" name="klantidvak"> <br />
    <input type="submit">
</form>

</body>
</html>